# Deploying-deep-learning-model-using-flask-API


**Introduction**


In this blog, we'll see how we can take your work and show it to an audience by deploying your projects on the web. Machine Learning engineers should know the implementation of deployment to use their models on a global scale.
About the Model
I build a model to predict fruit categories. In this model, Have 3 classes which are Apple, Banan, and Orange. I used VGG pre-trained model to perform this classification problem. Click here to learn more about this model implementation. In this blog, we are going to focus on only deployment using Flask.


**Saving Trained Models**


You can save your model by calling the save() function on the model and specifying the filename. But usually, we can save the model in 3 formats.

YAML

JSON

HDF5

To learn more follow my blog : https://medium.com/@draj0718/deploying-deep-learning-model-using-flask-api-810047f090ac

